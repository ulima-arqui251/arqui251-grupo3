const express = require('express');
const app = express();
const cors = require('cors');
const path = require('path');
const db = require('./models');

app.use(express.json());
app.use(cors());

// Servir imágenes estáticas
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const proveedoresRouter = require('./routes/proveedores');
app.use("/proveedores", proveedoresRouter);

app.use('/', require('./routes/aggregation'));

db.sequelize.sync().then(() => {
  app.listen(3002, () => {
    console.log("Servidor corriendo en puerto 3002");
  });
});
