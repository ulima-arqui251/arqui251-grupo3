# PROYECTO-Henry

PROYECTO-GRUPO3

1er paso:



en pgAdmin crear una base de datos llamada Arq con clave 12345678

2do paso:



(en carpeta cliente)

npm install

npm start

npm install react-turnstile

3er paso



(en carpeta servidor)

npm install

npm start

npm install react-turnstile

npm install axios

npm install express-rate-limit rate-limit-redis ioredis

npm install multer

npm install dotenv

npm install nodemailer  

4 en la carpeta raíz



npm install express-validator

npm install react-toastify

