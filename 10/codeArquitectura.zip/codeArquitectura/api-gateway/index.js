// gateway/index.js
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Servicio 1: Usuarios, Reservas, Pagos...
app.use(
  ['/usuarios', '/polideportivos', '/canchas', '/reservas', '/pagos', '/facturas'],
  createProxyMiddleware({
    target: 'http://localhost:3001',
    changeOrigin: true,
  })
);

// Servicio 2: Proveedores y Agregaciones
app.use(
  ['/proveedores', '/dashboard', '/aggregation'],
  createProxyMiddleware({
    target: 'http://localhost:3002',
    changeOrigin: true,
  })
);

// Puerto del gateway
app.listen(4000, () => {
  console.log('API Gateway corriendo en puerto 4000');
});
