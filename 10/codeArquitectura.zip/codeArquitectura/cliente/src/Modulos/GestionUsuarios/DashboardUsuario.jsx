import React, { useEffect, useState, useCallback } from 'react';
import servicioGeneral from './servicioGeneral';
import { Link } from 'react-router-dom';
import './VistaGeneral.css';

function VistaGeneral() {
  const [polis, setPolis] = useState([]);
  const [error, setError] = useState('');
  const [filtros, setFiltros] = useState({ ubicacion: '', tipo: '' });

  const cargarPolis = useCallback(async (aplicarFiltros = false) => {
    try {
      const datosPolis = await servicioGeneral.obtenerPolideportivos(
        aplicarFiltros ? filtros : {}
      );
      setPolis(datosPolis);
      setError('');
    } catch (err) {
      setError(err.message);
    }
  }, [filtros]);

  useEffect(() => {
    cargarPolis();
  }, [cargarPolis]);

  const handleInputChange = e => {
    const { name, value } = e.target;
    setFiltros(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="vista-general">
      <h2>Buscar Polideportivos</h2>

      <div className="filtros">
        <input
          name="ubicacion"
          placeholder="Ubicación"
          value={filtros.ubicacion}
          onChange={handleInputChange}
        />
        <input
          name="tipo"
          placeholder="Tipo"
          value={filtros.tipo}
          onChange={handleInputChange}
        />
        <button onClick={() => cargarPolis(true)}>Buscar</button>
      </div>

      <h3>Resultados</h3>
      {polis.length === 0 ? (
        <p>No hay polideportivos.</p>
      ) : (
        polis.map(p => (
          <div key={p.id} className="poli-card">
            {p.imagen && (
              <img
                src={`http://localhost:3001/${p.imagen}`}
                alt="Imagen del Polideportivo"
                className="poli-imagen"
              />
            )}
            <h4>{p.nombre}</h4>
            <p><strong>Dirección:</strong> {p.direccion}</p>
            <p><strong>Tipo:</strong> {p.tipo}</p>
            <Link to={`/reservar/polideportivo/${p.id}`}>
              <button>Reservar Polideportivo</button>
            </Link>
          </div>
        ))
      )}

      {error && <p className="error">{error}</p>}
    </div>
  );
}

export default VistaGeneral;
