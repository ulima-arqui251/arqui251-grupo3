import React, { useEffect, useState } from 'react';
import polideportivoService from '../Reservas/polideportivoService';
import './VerPolideportivos.css';

export default function VerPolideportivos() {
  const [polideportivos, setPolideportivos] = useState([]);
  const [editando, setEditando] = useState(null);
  const [form, setForm] = useState({ nombre: '', direccion: '', tipo: '' });
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    cargarPolideportivos();
  }, []);

  const cargarPolideportivos = async () => {
    try {
      const data = await polideportivoService.obtenerTodos();
      setPolideportivos(data);
    } catch (err) {
      setError('Error al cargar polideportivos');
    }
  };

  const handleEditar = (poli) => {
    setEditando(poli.id);
    setForm({
      nombre: poli.nombre,
      direccion: poli.direccion,
      tipo: poli.tipo,
    });
    setMensaje('');
    setError('');
  };

  const handleGuardar = async (id) => {
    try {
      await polideportivoService.actualizar(id, form);
      setEditando(null);
      setMensaje('Polideportivo actualizado correctamente.');
      cargarPolideportivos();
    } catch (err) {
      setError('Error al actualizar polideportivo');
    }
  };

  const handleEliminar = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar este polideportivo?')) return;
    try {
      await polideportivoService.eliminar(id);
      setMensaje('Polideportivo eliminado.');
      cargarPolideportivos();
    } catch (err) {
      setError('Error al eliminar polideportivo');
    }
  };

  const handleImagen = async (e, id) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      await polideportivoService.subirImagenPolideportivo(id, file);
      setMensaje('Imagen actualizada.');
      cargarPolideportivos();
    } catch (err) {
      setError('Error al subir imagen');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="ver-poli-container">
      <h2>Todos los Polideportivos</h2>
      {error && <p className="mensaje-error">{error}</p>}
      {mensaje && <p className="mensaje-exito">{mensaje}</p>}

      {polideportivos.map((poli) => (
        <div key={poli.id} className="poli-card-admin">
          {poli.imagen && (
            <img
              src={`http://localhost:3001/${poli.imagen}`}
              alt={poli.nombre}
              className="poli-card-img"
            />
          )}

          {editando === poli.id ? (
            <div className="poli-form-editar">
              <input name="nombre" value={form.nombre} onChange={handleChange} placeholder="Nombre" />
              <input name="direccion" value={form.direccion} onChange={handleChange} placeholder="Dirección" />
              <input name="tipo" value={form.tipo} onChange={handleChange} placeholder="Tipo" />
              <div className="poli-botones">
                <button onClick={() => handleGuardar(poli.id)}>Guardar</button>
                <button onClick={() => setEditando(null)}>Cancelar</button>
              </div>
            </div>
          ) : (
            <div className="poli-info">
              <p><strong>{poli.nombre}</strong></p>
              <p>{poli.direccion}</p>
              <p>Tipo: {poli.tipo}</p>

              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleImagen(e, poli.id)}
                className="poli-input-img"
              />
              <div className="poli-botones">
                <button onClick={() => handleEditar(poli)}>Editar</button>
                <button onClick={() => handleEliminar(poli.id)}>Eliminar</button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
